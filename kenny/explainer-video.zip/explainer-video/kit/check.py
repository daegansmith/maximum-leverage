#!/usr/bin/env python3
"""Check a built explainer: every scene fits the screen at three sizes, and the narration plays at 1.5x.

Usage: python3 check.py <out_dir> <slug>
Writes <out_dir>/check-<w>x<h>.png of the tightest scene at each size. Exits 1 on any failure.
"""
import sys, os, threading, http.server, functools, socketserver
from playwright.sync_api import sync_playwright
out, slug = sys.argv[1], sys.argv[2]
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a): pass
H = functools.partial(Q, directory=out)
srv = socketserver.TCPServer(("127.0.0.1", 0), H); port = srv.server_address[1]
threading.Thread(target=srv.serve_forever, daemon=True).start()
SIZES = [(1280, 720), (390, 844), (844, 390)]
MIN_SCALE = 0.6   # below this the text is too small: split the scene or cut words
bad = []
with sync_playwright() as p:
    b = p.chromium.launch(args=["--autoplay-policy=no-user-gesture-required"])
    for w, h in SIZES:
        pg = b.new_page(viewport={"width": w, "height": h}); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        pg.goto(f"http://127.0.0.1:{port}/{slug}.html"); pg.wait_for_timeout(1200)
        n = pg.evaluate("DATA.scenes.length"); worst = (9, 0)
        for k in range(n):
            if k: pg.click("#next")
            pg.wait_for_timeout(120)
            m = pg.evaluate("""()=>{const b=document.getElementById('fitbox'),e=document.getElementById('scene'),r=e.getBoundingClientRect(),q=b.getBoundingClientRect(),p=document.getElementById('player').getBoundingClientRect();
              return {s:+b.dataset.scale, over: r.height>q.height+1 || r.width>q.width+1, player:p.bottom<=innerHeight+1, sw:document.documentElement.scrollWidth<=innerWidth}}""")
            if m["over"] or not m["player"] or not m["sw"]: bad.append(f"{w}x{h} scene {k+1}: does not fit {m}")
            if m["s"] < (0.45 if h < 500 else MIN_SCALE): bad.append(f"{w}x{h} scene {k+1}: scale {m['s']} is too small, split it")
            if m["s"] < worst[0]: worst = (m["s"], k)
        for _ in range(n - 1 - worst[1]): pg.click("#prev"); pg.wait_for_timeout(60)
        pg.evaluate("document.querySelectorAll('.bit').forEach(b=>b.classList.add('on'))")
        pg.wait_for_timeout(500); pg.screenshot(path=os.path.join(out, f"check-{w}x{h}.png"))
        print(f"{w}x{h}: tightest scene {worst[1]+1} at scale {worst[0]}")
        if w == 1280:
            pg.click("#play"); pg.wait_for_timeout(2500)
            a = pg.evaluate("({t:document.getElementById('vo').currentTime, r:document.getElementById('vo').playbackRate})")
            if not (a["t"] > 0.5 and a["r"] == 1.5): bad.append(f"audio not playing at 1.5x: {a}")
            else: print(f"audio ok: {a}")
        if errs: bad.append(f"{w}x{h} page errors: {errs}")
        pg.close()
    b.close()
print("\n".join(bad) if bad else "ALL CHECKS PASS"); sys.exit(1 if bad else 0)
