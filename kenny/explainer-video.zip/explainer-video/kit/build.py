#!/usr/bin/env python3
"""Build a narrated explainer page.

Usage: python3 build.py <scenes.json> <out_dir> [--template template.html] [--models DIR]

scenes.json: {"title", "slug", "pron": {...optional}, "scenes": [ {chapter, type, h, ..., "vo": [[line, reveal], ...]} ]}
Each vo line is written as readable text. "reveal" = how many of the scene's on-screen pieces
are visible once that line starts (heading = 1, then each item/node/row/chip, then caption, analogy, note).
The narration is synthesized line by line with Kokoro, so its timing becomes the master clock.

Outputs ONE file, <out_dir>/<slug>.html, with the narration packed inside it, so it plays anywhere on its own.
Also writes <out_dir>/<slug>.mp3 in case the sound is wanted separately.
"""
import json, sys, os, re, hashlib, subprocess, argparse, base64
import numpy as np, soundfile as sf

# Spoken forms for things TTS mangles. Keys are matched case-sensitively, longest first.
DEFAULT_PRON = {
    "CLAUDE.md": "Claude dot M D",
    "SKILL.md": "skill dot M D",
    ".md": " dot M D",
    "GitHub": "Git Hub",
    "1.5×": "one and a half times",
}
VOICE, RATE = "am_michael", 1.1          # Kokoro "Michael", a little faster than default
GAP_LINE, GAP_SCENE, LEAD = 0.28, 0.85, 0.35

def spoken(text, pron):
    for k in sorted(pron, key=len, reverse=True):
        text = text.replace(k, pron[k])
    return re.sub(r"\*\*|`", "", text)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("scenes"); ap.add_argument("out")
    here = os.path.dirname(os.path.abspath(__file__))
    ap.add_argument("--template", default=os.path.join(here, "template.html"))
    ap.add_argument("--models", default=os.environ.get("KOKORO_DIR", os.path.expanduser("~/explainer-voice")))
    a = ap.parse_args()
    d = json.load(open(a.scenes)); slug = d["slug"]
    pron = {**DEFAULT_PRON, **d.get("pron", {})}
    os.makedirs(a.out, exist_ok=True); cache = os.path.join(a.out, ".vo-cache"); os.makedirs(cache, exist_ok=True)

    from kokoro_onnx import Kokoro
    k = Kokoro(os.path.join(a.models, "kokoro.onnx"), os.path.join(a.models, "voices.bin"))
    sr = 24000; parts = [np.zeros(int(LEAD*sr), dtype=np.float32)]; t = LEAD; timeline = []
    for si, sc in enumerate(d["scenes"]):
        assert sc.get("vo"), f"scene {si+1} has no narration"
        ent = {"start": round(max(0, t-0.05), 3), "lines": []}
        for li, (text, reveal) in enumerate(sc["vo"]):
            say = spoken(text, pron)
            h = hashlib.sha1(f"{VOICE}|{RATE}|{say}".encode()).hexdigest()[:16]
            fn = os.path.join(cache, h + ".wav")
            if not os.path.exists(fn):
                audio, sr = k.create(say, voice=VOICE, speed=RATE, lang="en-us")
                sf.write(fn, audio, sr)
            audio, sr = sf.read(fn, dtype="float32")
            dur = len(audio)/sr
            ent["lines"].append({"t": round(t, 3), "end": round(t+dur, 3), "text": re.sub(r"\*\*|`", "", text), "r": int(reveal)})
            parts.append(audio); t += dur
            gap = GAP_LINE if li < len(sc["vo"])-1 else GAP_SCENE
            parts.append(np.zeros(int(gap*sr), dtype=np.float32)); t += gap
        timeline.append(ent)
    wav = os.path.join(cache, "_all.wav"); sf.write(wav, np.concatenate(parts), sr)
    mp3 = os.path.join(a.out, slug + ".mp3")
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", wav, "-af", "loudnorm=I=-16:TP=-1.5:LRA=11", "-ar", "24000", "-ac", "1", "-b:a", "64k", mp3], check=True)

    scenes = [{kk: vv for kk, vv in sc.items() if kk != "vo"} for sc in d["scenes"]]
    audio_uri = "data:audio/mpeg;base64," + base64.b64encode(open(mp3, "rb").read()).decode()
    data = {"title": d["title"], "scenes": scenes, "timeline": timeline, "total": round(t, 3), "audio": audio_uri}
    html = open(a.template).read().replace("{{TITLE}}", d["title"]).replace(
        "{{DATA}}", json.dumps(data, ensure_ascii=False).replace("</", "<\\/"))
    open(os.path.join(a.out, slug + ".html"), "w").write(html)
    print(f"{slug}: {len(scenes)} scenes, {t:.1f}s at 1x, {t/1.5:.1f}s at 1.5x, one file {os.path.getsize(os.path.join(a.out, slug + '.html'))//1024} KB")

if __name__ == "__main__":
    main()
