#!/bin/sh
# One-time setup per session: installs the voice. Safe to run again.
set -e
D="${KOKORO_DIR:-$HOME/explainer-voice}"
mkdir -p "$D"
pip install --break-system-packages -q kokoro-onnx soundfile numpy 2>/dev/null || pip install -q kokoro-onnx soundfile numpy
B=https://github.com/thewh1teagle/kokoro-onnx/releases/download/model-files-v1.0
[ -s "$D/kokoro.onnx" ] || curl -sSL --fail -o "$D/kokoro.onnx" "$B/kokoro-v1.0.int8.onnx"
[ -s "$D/voices.bin" ] || curl -sSL --fail -o "$D/voices.bin" "$B/voices-v1.0.bin"
python3 -c "import playwright" 2>/dev/null || pip install --break-system-packages -q playwright 2>/dev/null || pip install -q playwright || echo "note: Playwright did not install; the step 4 check cannot run"
python3 -m playwright install chromium >/dev/null 2>&1 || echo "note: Chromium for Playwright did not install; the step 4 check may not run"
command -v ffmpeg >/dev/null || { echo "ffmpeg is missing: install it (apt-get install -y ffmpeg, or pip install imageio-ffmpeg) before building"; exit 1; }
ls -la "$D"; echo "voice ready in $D"
