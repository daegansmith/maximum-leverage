---
name: explainer-video
description: Make a short narrated explainer on any topic, a voiced, self-playing page where the visuals follow the voice, delivered as one file. Use for "explainer", "explainer video", "make me an explainer on X", "teach me X", "walk me through X". Also offer one when the person is starting a topic that is new to them and says they feel lost.
---

# Explainer video

From Daegan Smith's explainer skill. This is a clean copy to make your own. Change it as you learn what works for you.

**At a glance:** a topic goes in. A narrated explainer comes out: one HTML file that plays by itself, with a voice, visuals that follow the voice, chapters, captions and a full transcript. It plays at 1.5× by default, with a speed control.

**The purpose.** An explainer is a front door to a new topic. It gets the person from "I don't know what this is" to "I see how it works and what to ask next" in a few minutes, so they can start working on the real thing.

## When It Runs

**They say:** "explainer", "explainer video", "make me an explainer on X", "do a video for me on X", "teach me X", "walk me through X", "show me how X works".

**Claude notices** (offer in one line, never build unasked): the person is starting something new to them and says they are lost, or has asked three or more basic questions in a row about the same new topic.

**Not this skill:** a quick answer in the chat ("just explain it to me"), a slide deck to present, a marketing video, a single drawing of one idea (use napkin-sketch if it is installed).

## The three rules everything rests on

1. **There is always narration.** An explainer without a voice is a slide deck. The voice is the point.
2. **The narration is the master clock.** Write it, voice it, and measure it first. Scene timing and reveals all come from the measured audio, never from guesses. `build.py` does this.
3. **Every scene fits one screen.** The player is exactly one screen tall, on a phone, a desktop, or a phone turned sideways. Nothing scrolls while it plays. The template scales each scene to fit, and `check.py` proves it.

## How to teach (apply every time)

- **Mechanism first.** Say how the thing works, plainly. Skip hype and hedging.
- **One analogy per idea, from the person's own world.** Their job, their field, things they already do. One per scene, at most. If you know nothing about them, use an everyday one anyone knows, and say in your reply that you did.
- **Use their real context, never generic examples.** Their project, their tools, their words from this chat and from the project's files. Ask one question first only if the topic is truly ambiguous; otherwise say at the top of your reply which reading you took.
- **Write tight.** Target 2 to 4 minutes at 1.5× for a full topic. When they ask for a short one (four or five scenes), about one minute at 1.5× is right.
- **Look up anything current** (prices, features, names, who holds what role) before it goes in the script. Keep the list of sources for the reply.
- **Flag, don't guess.** Names, numbers and terms the person dictated get flagged for confirmation in the reply.
- **Plain words, conversational, second person.** Short sentences.

## Learning rules

- **The voice explains and the screen shows key words.** Never have the narration read the screen word for word.
- **Reveal each item as it's spoken.**
- **Chunks the viewer controls:** 3 to 6 chapters, each scene one idea.
- **Vocabulary before process.** Name the parts before showing how they move.
- **Cut whatever doesn't serve the goal.**

## Pipeline

Do every step, in order.

### 0. Set up (once per session)

The kit is in the `kit/` folder next to this file: `template.html`, `build.py`, `check.py`, `setup.sh`, `example-scenes.json`. Make a work folder, copy the whole `kit/` folder into it, and run every command below from that work folder. Then install the voice:

```
sh kit/setup.sh
```

This installs the Kokoro voice (about 120 MB, downloaded from GitHub), checks for ffmpeg, and tries to install Playwright with Chromium for the check in step 4. If it fails because the download is blocked or a tool is missing, stop and tell the person plainly what failed. Do not hand over a silent explainer and call it finished. Offer a written walkthrough in the chat instead.

### 1. Research and context

Read what the person has said and any project files that bear on the topic. Look up anything current.

### 2. Write `scenes.json`

Start from `kit/example-scenes.json`. Shape:

```
{"title": "Short Name", "slug": "kebab-slug", "pron": {"OddWord": "how to say it"},
 "scenes": [{"chapter": "...", "type": "...", "h": "Heading", ...fields, "vo": [["Narration line.", reveal], ...]}]}
```

**Scene types and their fields:**

- `title`: `h`, `sub`
- `text`: `items[]`
- `steps`: `items[]` (only for a real sequence)
- `flow`: `nodes[{t,s,hi}]` (a left-to-right process; mark the endpoint `hi`)
- `tree`: `lines[]` (folder structure; `#` starts a comment)
- `graph`: `rows[{lane:0|1,msg,span}]` (history or branches)
- `compare`: `a{label,items}`, `b{label,items}` (before and after)
- `chips`: `items[[term,meaning]]` (a vocabulary recap)

**Optional fields on any scene:** `sub`, `caption`, `analogy`, `note`. Text may use `**bold**` and `` `code` ``.

**`reveal`** is how many on-screen pieces are visible once that line starts. Pieces are counted in this order: heading = 1, then `sub`, then each item, node, row, chip or column, then `caption`, `analogy`, `note`. A whole `tree` counts as one piece. In `compare`, each side is one piece. In `graph`, `span: true` lets a row's text run the full width. The last line of a scene should reveal everything.

**Narration rules:**

- 2 to 6 lines per scene, each line 1 to 2 sentences.
- About 8 to 25 seconds per scene, at normal speed. `build.py` prints the total; if one scene has more than six lines, split it.
- Put names, web addresses and acronyms the voice would mangle in `pron`.
- Spell out symbols in narration ("two in the morning", not "2 AM").
- Screen text stays short. The narration carries the explanation.

**Sizing rules (so a scene never has to shrink much):**

- At most 5 items, 5 flow nodes, or 6 chips in a scene. More than that is two scenes.
- Each on-screen line stays under about 12 words.
- Use at most two of `sub`, `caption`, `analogy`, `note` on one scene.

### 3. Build

```
python3 kit/build.py scenes.json out
```

This voices each line (cached, so only changed lines get re-recorded), measures every line, levels the loudness, and writes one file, `out/<slug>.html`, with the narration packed inside it. Voicing takes roughly as long as the narration runs. If a run is cut off, run it again: finished lines are kept.

### 4. Check once

```
python3 kit/check.py out <slug>
```

This opens the page at three sizes (desktop, phone, phone sideways), steps through every scene, and fails if any scene overflows, the text had to shrink below 0.6, there are page errors, or the narration isn't playing at 1.5×. It saves a picture of the tightest scene at each size. Look at all three, fix what they show, and don't loop. If a scale is under 0.6, split the scene or cut words.

`check.py` needs Playwright with Chromium. `setup.sh` tries to install it (`pip install playwright` then `playwright install chromium`). If it can't be installed here, say the check did not run. Do not say it passed.

### 5. Deliver

Give the person the one file, `out/<slug>.html`. It opens in any browser, on a phone or a computer. The sound is inside the file. (It loads its fonts from the internet; offline it still plays, in plainer type.) If this session can publish a page they can open from a link, do that too.

### 6. Reply

In 2 to 4 lines, say what the explainer covers and how long it runs at 1.5×. Flag any names or pronunciations to confirm, and any assumptions you made. End with a Sources list, or say that nothing was looked up. Don't recap the steps.

## Making it better

This skill should get a little better each time it runs.

- When the person gives feedback (pace, voice, length, sizing, a visual), propose the change to this file in the same reply, and add one dated line to the Lessons log.
- If the same thing had to be fixed by hand twice, it becomes a rule.
- The voice is Kokoro `am_michael` at speed 1.1, set at the top of `kit/build.py`. Change it there if they want another.

## Lessons log

- Without a voice it's just slides. Narration is not optional.
- Explainers that run long down the page are awkward. One screen per scene, scale to fit, and check at three sizes.
- A 6-chip scene is the limit on a phone turned sideways.
- Don't ask a quiz question before the video. Give the explainer, then let them ask.
