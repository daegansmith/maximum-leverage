---
name: napkin-sketch
description: Find the picture that makes an idea land, rough first, then draw it clean, as a hand-drawn marker doodle or a process map. Use for "doodle this", "napkin", "back of the napkin", "draw this", "show me the visual", "map the steps", "draw how we do it now and the new way". Also offer one when an explanation turns on a difference (before and after, this against that) and has no picture.
---

# Napkin Sketch

From Daegan Smith's napkin skill, built on Dan Roam's book *The Back of the Napkin*. This is a clean copy to make your own. Change it as you learn what works for you.

**The purpose.** A doodle is a tool for understanding first and explaining second. Drawing an idea, from a few angles, until one is right, is how you get closer to how the thing actually works. When it lands, it says more than the words. Then it can carry that understanding to anyone. The doodle is how the person comes to own the idea.

An example of a doodle that works: an offer drawn as a canyon. Someone thirsty on one side, all the water on the other, and the gap just wide enough that they can and will jump. No gap, no meaning. Too wide, no jump.

The look: every doodle is made the same way. Rough and fast to find the picture, then one clean redraw. One pen, one weight, plenty of empty paper. Dan Roam's questions pick the kind of picture. The pen in the engine at the bottom of this file draws it.

## When It Runs

**They say:** "doodle this", "napkin", "back of the napkin", "draw this for me", "show me the visual", "what would the visual be", "draw how it works", "draw it now and draw the new way", "map the steps", "process map", "make it a comic strip".

**Claude notices** (offer in one line; never draw unasked):

- The person has explained the same idea twice and it still isn't clear.
- The explanation turns on a difference (before and after, with and without, this against that) and has no picture.
- A visual in front of them is a row of labeled boxes.

One sign is enough to offer. An ask is enough to draw.

**Not this skill:** a chart for studying data, a narrated explainer video, a page or screen mockup, a logo.

## The Path

Every doodle walks these nine steps, 0 to 8, in order. Steps 0 to 5 are rough and fast. Step 6 is the only polished one. The sections after this one are the tools the steps use; they are named, not numbered.

**Two depths.** The person picks, or Claude says which one is running in one line before starting.

- **Shape pass.** To get the shape of something quickly. Steps 0 to 4, then Claude picks the angle and says which, then one clean redraw. Fix the engine's warnings, read the ink number and look at the picture. No blind read. It does not claim the idea is owned. "A quick one" means a shape pass.
- **Own-it pass.** To come to own the idea. Each of the six questions (who or what, how much, where, when, how, why) is tried, several angles are drawn, the one that says more than the words is found, then the clean redraw and the blind read.

Say which depth ran. A shape pass is never described as an own-it pass. A skipped step is said out loud with the reason, never silent.

0. **Does it earn a doodle?** Only the moments that matter: a lesson, a contrast, a process, a turn. Most ideas get none.
1. **Understand it first.** Say what is actually true about the idea in one plain sentence. If that can't be done yet, drawing is how you find out.
2. **Room or glance?** Room: the person will explain it out loud, so their own symbols work. Glance (an article, an email, a post): nobody explains it, so it uses only things everyone on earth knows, like a cliff, a cup of water or a door.
3. **The key.** The person's own symbols, each with its meaning. Keep a short list under "The Key" near the bottom of this file and add a symbol only when it earns its place in a real doodle. If you can't edit this file, show the person the line to add. Never invent symbols in bulk.
4. **Play the six questions.** Is it a path, a before and after, how much, where, why? Rough thumbnails from three or four angles: drawn with the engine, small, fast, not polished. Expect some to half work.
5. **Look for "more than the words."** Which angle makes the thing understood better? The person picks. If none does, say "not there yet," list the angles tried, and come back another day. Never fake one to fill a slot.
6. **Draw it clean.** One pen, one weight. Two jobs, two modes: a concept doodle (plants one belief) or a process map (shows the steps). For something new to be understood, give both: the map first, then the payoff.
7. **Check it the right way.** Glance pieces: the blind read with the words covered (see Check It Before They See It). Room pieces: does it carry the lesson with the person explaining it?
8. **Keep what was learned.** New symbols to the key, and anything that changes how doodles get drawn goes into this file.

## First Principles

A doodle moves one idea from one head to another in about three seconds. Every rule below comes from what the eye does, in this order:

1. Contrast first. The darkest, biggest, or only colored thing wins.
2. Faces and bodies second. A face with a feeling tells the viewer how to feel.
3. Direction third. Arrows, a lean, left to right.
4. Words last, and only a few.

So the idea has to be the thing with the most contrast, a person has to feel it, something has to move, and the words only name things. When a rule here and a doodle disagree, go back to these four.

## The One Idea And The Feeling

Write the idea as one sentence. If the idea takes two sentences, it is two doodles.

Put that sentence in the chat, above or under the drawing, every time, so the person can judge whether the picture carries it. It does not go inside the picture.

When there is a real story, the picture comes from it: get the raw story first, draw only the beats where it turns, and use its real details.

Then name the one feeling the picture should leave: clarity, trust, fear, hope, sobering reality, gusto, courage, commitment, reward or aspiration. The feeling picks the face.

## Find The Difference

A doodle is a picture of a difference. No difference, no picture, only a label. Name the two sides before anything else: before and after, without and with, small and big, leak and plug, stuck and moving, alone and together, expected and got.

The two sides differ in one thing only, and that thing is the idea. Everything else is drawn the same on both sides.

## Make It Physical

An idea about paper, software or AI drawn as paper, software or AI fails with the words off. Find the thing everyone has already seen that works the same way, and draw that. "A rule written down is not a rule read" is a stop sign someone rolls past.

- **Who:** a person the viewer can be, with the feeling on the face. The AI is the robot.
- **What:** a thing you could drop on your foot. Never a box with a word in it.
- **What moves:** one visible verb (pouring, lifting, rolling past, handing over).

| The abstract thing | Draw |
| --- | --- |
| Money | Coins, a bag, a bucket filling |
| Lost money | A leak, a drain, coins rolling away |
| Time | A clock, a calendar, a long road |
| Customers | People, a line at a door |
| Effort | Sweat drops, a lean, pushing |
| Leverage | A lever, a ramp, a pulley |
| Growth | Bars going up, stairs, a plant |
| A problem | A wall, a boulder, a hole |
| A rule | A road sign |
| A system | A machine, pipes, a conveyor |
| Confusion | A tangle, a fork in the road |
| An idea | A bulb |
| A plan or a document | A sheet of paper |
| Saying it | A speech bubble |
| Risk | A cliff, a tightrope |
| Hidden | An iceberg, a closed door |

Four moves that make a difference visible:

- **Same frame, one change.** The close redraws the opening picture with one thing swapped.
- **Split the twin words.** When two words get mixed up (closest and fastest), draw them as two separate things side by side.
- **Draw the cliché literally.** "The door was printed on my ticket" is a ticket with a door on it.
- **One odd one out.** A row of the same thing, one different, and that one carries the accent.

A category is not a thing: "lesson," "content," "strategy" can't be drawn. Give it a physical stand-in everyone recognizes, or let the headline name what the picture actually shows.

Push the difference until it is almost silly. A small person, a huge boulder.

A metaphor gets one label: the real thing it stands for, written big on the object itself (the lever says "AI"). Cover the label: the object must still be something anyone can name. A blob marked "the work" is not a picture; a gym weight marked "WORK" is. A label never floats beside a thing, it sits on it.

## Pick The Picture From The Question

Ask which question the idea answers. The question picks the picture. (This is Dan Roam's Visual Thinking Codex.)

| The question | The picture |
| --- | --- |
| Who or what | A portrait: the people and things, and how they relate |
| How much | A chart, usually bars |
| Where | A map: where things sit in relation to each other |
| When | A timeline, or an arc strip |
| How | A flowchart: this, then this, then this |
| Why | A plot with two or more variables that shows the reason |

Then set the five dials. Say each choice in a word.

- Simple or elaborate. Default simple.
- Quality or quantity. Words and shapes, or numbers.
- Vision or execution. Where we are going, or how we get there.
- Individual or comparison. One thing, or this against that.
- Change or the way things are. Before and after, or a snapshot.

Tell the person the pick in one line: "This is a how question, so a flowchart; simple, comparison, change."

In an own-it pass, give three clean ones, not one: the same idea three ways, from three different rows of the table, each tagged with its row. The person picks. Give a single clean doodle when they name the kind of picture themselves or ask for a quick one.

## Stage It

- **One hero.** It fills at least a third of the canvas, and it is the idea.
- **Bad on the left, good on the right.** More is up.
- **One accent color** (`HOT`, red), on the hero. Green (`GO`) only as the fixed half of a red-to-green pair. One color, one meaning. Gray (`FADE`) only for something meant to fade into the past.
- **One pen.** The drawing's lines all share one weight. Lettering is a little lighter than the drawing, and the title a touch heavier than the labels, never heavy. The title's underline is one plain black line (`d.line`) running the full width of the title; it does not count as the doodle's one emphasis. Nothing too thick next to something too thin.
- **Seven things or fewer.** Plenty of empty paper.
- **Words:** a headline of five words or fewer, plus up to four labels of one or two words. Capitals. Left-aligned, unless it sits over a centered picture.
- **Every verb in the words is visible in the picture.** "Read out loud" needs a speech bubble.
- **Real numbers only.** Nothing invented. If the person gave no numbers, ask, or work a real example and say in the chat what you assumed.
- **Symbols ($, ?, !, %) are picture, not words.** They stay when the words come off.

## Draw It With The Engine

Save the last code block in this file (under The Engine) as `marker.js` in your work folder, exactly as written. Each doodle's script goes in the same folder. Do not restyle it for a job. The hand stays the same because the code stays the same. It needs Node, the pen (`npm i perfect-freehand`), and one renderer: `rsvg-convert` if the machine has it, otherwise `npm i @resvg/resvg-js`.

Draw the clean redraw with looseness 0.2, at the size from the table below: for example `Doodle(...SIZES.letter, seed, 0.2)`. Title: `d.text(title, x, y, 58 to 66, { anchor: 'start', w: 0.65 * u to 0.72 * u })`, then `d.line` under it at `{ w: 0.6 * u }` to the end of the title. Write lettering in capitals; they read cleanest.

Smoke test before the first drawing: `node -e "const {Doodle}=require('./marker.js');const d=Doodle(1200,800);d.text('OK',600,300,160);d.person(300,720,300);d.robot(900,720,300);d.save('smoke')"`. If that throws, the engine text was damaged in copying. A "thin" warning on this test is expected.

Write one small script per doodle. `d.save('name')` writes `name.svg`, `name.png` (double size), `name-bare.png` (words off) and `name-thumb.png` (320 wide), and prints the ink share and any warnings. Then look at the PNG before showing it.

**Sizes** (`Doodle(...SIZES.email)`). Everything scales from the width, so one script redraws at any size.

| Where it is going | Size | Note |
| --- | --- | --- |
| Email | `email` 1200 x 800 | Shows at about 600 wide. Five things at most |
| Article, lesson | `letter` 1400 x 840 | Sits in the column |
| Slide, full | `slide` 1600 x 900 | |
| Slide, picture half | `half` 1000 x 1000 | Words left, picture right |
| Social, square | `square` 1080 x 1080 | Headline inside the picture |
| Social, tall | `portrait` 1080 x 1350 | Headline inside the picture |

**What the engine draws.** `u` is 1% of the width. A style is `{ w: line width, c: line color, f: fill }`. Closed shapes fill white unless told otherwise, so things can stand in front of things. Draw back to front.

| Kind | Calls |
| --- | --- |
| Lines | `d.line(x1,y1,x2,y2,st)` `d.poly(pts,st)` `d.curve(pts,st)` `d.arc(cx,cy,rx,ry,a0,a1,st)` |
| Shapes | `d.shape(pts,st)` `d.blob(pts,st)` `d.rect(x,y,w,h,{r})` `d.oval(cx,cy,rx,ry,st)` `d.dot(x,y,r,c)` `d.tube(pts,width,{f})` (a limb, pipe, post or plank) |
| Groups | `d.rot(cx,cy,degrees,fn)` `d.with({w,c},fn)` (draw a group in gray, in red, or with another pen) |
| Arrows | `d.arrow(x1,y1,x2,y2,{bend,head})` `d.bigArrow(x1,y1,x2,y2,thickness,{f})` |
| Lettering | `d.text(words or [lines], x, baselineY, letterHeight, {c, anchor:'start', rot, lead, w, loose})` `d.textW(words,size)`. The letters are a real person's handwriting, traced, so they look written, not typed |
| Emphasis, one per doodle | `d.underline` `d.ring` `d.zing` `d.cross` `d.check` `d.hatch` `d.bubble(x,y,w,h,[tailX,tailY])` |
| People | `d.person(x, groundY, height, {mood, look, arms, hair, lean, walk, sweat, c})`: a stick figure. Round head, dot eyes, one-line body |
| The AI | `d.robot(x, groundY, height, {mood, look, arms, c})`: a stick robot, box head and antenna |
| Props | `d.doc` `d.bag` `d.coin` `d.phone` `d.bulb` `d.clock` `d.shop` `d.bars(x,baseY,w,h,[values],{hot,tops,labels})` |

Moods: happy, sad, worried, mad, flat, wow. `look` is -1, 0 or 1. Arms: down, up, out, point, hold, shrug, head, hips, or `[[lx,ly],[rx,ry]]`, where each hand sits, in units of the figure's height measured from the feet (up is negative). Anything not in the props is built the same way, from shapes: a bucket is a `shape`, an `oval` and a `curve`.

**A worked example** (a lever: small push, big lift):

```js
const { Doodle, SIZES, HOT, INK, PAPER } = require('./marker.js');
const d = Doodle(...SIZES.square, 21, 0.2), u = d.u;
d.text('SMALL PUSH.', 60, 160, 100, { anchor: 'start', w: 1.0 * u });
d.text('BIG LIFT.', 60, 298, 100, { anchor: 'start', w: 1.0 * u });
d.line(50, 940, 1030, 940);                                                          // the ground
const cx = 595, cy = 785, L = 830, T = 84;                                          // the plank: centre, length, thickness
d.shape([[628, 940], [778, 940], [703, 800]]);                                       // the pivot
d.rot(cx, cy, -13.2, () => {
  const by = cy - T / 2, ty = by - 214;                                              // the load: a weight anyone knows, solid, ring on top
  d.arc(880, ty, 38, 40, 180, 360);
  d.shape([[752, by], [1006, by], [962, ty], [798, ty]], { f: INK });
  d.text('WORK', 880, by - 50, 48, { c: PAPER, w: 0.85 * u });                     // the label sits on the thing it names
  d.rect(cx - L / 2, cy - T / 2, L, T, { f: HOT, r: 14 });                           // the one red thing
  d.text('AI', 410, cy + 27, 56, { c: PAPER, w: 0.95 * u });
});
d.person(112, 940, 320, { mood: 'happy', look: 1, arms: [[-0.17, -0.38], [0.37, -0.31]] });
d.save('lever');
```

## Check It Before They See It

Look at the rendered images, not the code.

1. **The warnings.** Fix every one the engine prints: off the edge, small letters, hairline, too many words, too many colors.
2. **Bold by numbers.** The engine measures how much of the page is ink. Bold is 8% to 20%. Under 7%, make the hero bigger or fill a shape. Do not add things. Over 20%, take something out.
3. **Cover the labels.** Hide every word. Name every object out loud. Anything you cannot name is a blob: redraw it as a thing everyone knows.
4. **The squint.** Open `-thumb.png`. The hero and the difference still read at that size.
5. **The blind read, words off.** If a fresh reader is available (a separate agent that has not seen the brief), give it `-bare.png` and ask: where did your eye land first, what is this telling you in one sentence, how sure are you from 1 to 5. Pass is the one-sentence idea back at 4 or 5, and the eye landing on the hero. If no fresh reader is available, say the blind read did not happen.
6. **The blind read, words on.** The same reader then gets the full picture: do the words and the picture say the same thing?

If a read fails twice, tell the person the idea is not landing as a picture yet, and show what the reader said. Do not show it as finished.

## Pre-Decisions

Made in advance, so the old habits lose.

- If I am about to draw a box with a word in it, then I draw the thing the word names.
- If the picture only works with its label, then the picture is wrong. I redraw it; I do not add a label.
- If a blind read misses, then I change something or take something out. I never add.
- If the subject is paper, software or AI, then I find the everyday object that behaves the same way first.
- If a comparison has two sides, then they differ in one thing only.
- If two things are the same size, then one of them is not the hero. I make the idea three times bigger.
- If nothing in the picture is doing anything, then I add the verb.
- If there is no face, then I ask who feels this and put them in.
- If the scene needs more than the cast and props can show, then I cut it down to its one action, or I give the image prompt below and say why.

## Process Map Mode

For showing the steps rather than planting one belief.

- **Each station is a label and one small icon that is its meaning:** a bulb for the idea, a brick wall for the obstacle, a target for the goal, a coin for the money, a door for the invitation. Never a box around a word.
- **Labels are one to three words,** right under their icon, with a short plain line under each saying what it means.
- **The path runs left to right.** When it is long it snakes: left to right, down, right to left, so the eye never jumps back. A loop gets a curved arrow.
- **Black ink.** One small accent at most, on the payoff.
- **Room between stations.** If two labels touch, cut a station, shorten the lines, or make the canvas bigger.

The engine's word-count and lettering warnings are expected in this mode. The rest still hold: no off-edge, no hairlines.

## Show The Work, Then The Payoff

When something new has to be understood (a tool, a system, a process), give the pair, in this order:

1. **The map.** The steps, each with its plain line.
2. **The payoff.** The before and after: what changes for the person.

Together they mean more than the payoff alone. The map defines the words the payoff picture leans on.

## The Arc Strip

When the idea is a process that went wrong before it went right, draw the arc.

- Three to six frames on one canvas, about 500 wide each. Each frame is a small scene: two of the cast and one prop. Never a row of symbols.
- The words live in a caption under each frame, five words or fewer. No lettering inside the frames.
- The frame that shows the fix is drawn in the accent.
- One line under the frames with the honest limit: where it did not hold.

## When The Scene Is Too Rich For The Pen

The engine draws a simple cast and simple props. When a doodle needs something it cannot draw (a crowd, a map, a street scene, a real person's likeness), say so in one line before drawing, and give this prompt with the scene filled in, for whatever image tool the person uses:

> Hand-drawn marker doodle on a flat white background. Medium-weight black felt-tip line, confident and even, drawn fast by a smart friend on a napkin. Stick figures with round heads and dot eyes. Bold hand-lettered capitals. One accent color, a warm red, on [the hero] only. No shading, no gradients, no paper texture, no extra scenery. Scene: [who, doing what, to what; what is on the left, what is on the right]. Words in the picture: [headline], [labels].

## Put It In Front Of Them

The images in the chat. With them: the one-sentence idea, the one-line pick, and what the blind reader said in a line. Then the high-level question first: does the picture carry the idea? Details after.

When they ask to refine a visual, they mean simplify and clarify: fewer, shorter labels. Never bigger or denser.

A correction that changes how doodles get drawn is proposed back into this skill in the same reply: show the person the lines to change.

## Lessons

- Adding to fix a miss makes it worse. One doodle went from 4 of 5 to 2 of 5 when a speech bubble was added and nothing was taken out.
- The eye lands on the accent color first, every time. Put it on the idea.
- Words and picture have to share their verbs, and the accent belongs on the thing the headline names.
- A lever with a blob marked "the work" fails at a glance. Cover the labels and name every object.
- Some ideas need their words. Say so when one does.
- When the look is close, show options side by side. Three different pictures of one idea beat one picture drawn four ways.
- Chasing "bold" with a heavy pen makes pages look messy: thick next to thin. One even pen, rough first, clean last.

## The Key

(Empty to start. Add a symbol and its meaning here each time one earns its place in a real doodle.)

## The Engine (marker.js)

```js
// marker.js : the hand. One file, no fonts; needs the perfect-freehand package. Every line, letter and figure is drawn by the same pen,
// sized as a share of the canvas (u = 1% of the width), so a doodle is as bold on a phone as on a slide.
// Use: const { Doodle, SIZES, HOT, GO, FADE, INK } = require('./marker.js'); const d = Doodle(...SIZES.email); ...; d.save('name');
const fs = require('fs'), cp = require('child_process'), zlib = require('zlib');
const INK = '#141414', HOT = '#D2452B', GO = '#1E9B57', FADE = '#B9B9B9', PAPER = '#FFFFFF';
const SIZES = { email: [1200, 800], letter: [1400, 840], slide: [1600, 900], half: [1000, 1000], square: [1080, 1080], portrait: [1080, 1350] };

// HAND-TABLE
// The alphabet is a real person's handwriting: the pen path of every letter, traced from the handwriting font "Mynerve" (SIL Open Font License 1.1)
// and re-drawn here with the marker. [how far to move on, 'x,y x,y;x,y ...'] on a grid where 0 is the top of a capital and 100 is the line it sits on.
const HAND = { name: 'Mynerve', xh: 65, sp: 38 };
const G = {
  A: [93, '79,101 71,58 67,55 60,38 51,21 44,17 40,19 38,24 26,54 24,68 21,71 13,90 11,94;67,56 32,68 24,68'],
  B: [90, '51,43 65,47 75,55 78,62 76,72 69,80 58,87 34,96 21,96 13,16 14,11 19,8 32,7 46,8 56,12 60,18 60,24 51,43;34,50 51,43'],
  C: [101, '67,21 57,12 47,10 36,15 25,26 19,36 15,51 16,70 20,85 26,93 34,98 43,101 53,100 76,92 94,78'], D: [98, '34,7 32,27 32,80 30,94 35,99 44,97 51,94 72,77 78,68 82,60 82,46 74,31 58,17 44,9 34,7 32,4 24,-1 17,-3 11,-2'],
  E: [83, '73,4 68,6 39,8 26,9 14,6;71,82 51,92 40,94 33,93 26,86 22,79 21,61 26,9;64,40 49,48 22,54'], F: [76, '15,104 19,46 19,12 24,7 45,0 57,-1 63,3;19,51 57,45 66,46'],
  G: [94, '34,59 45,60 71,58 81,60 83,66 78,76 59,91 48,95 38,96 28,94 21,87 17,81 15,73 17,59 31,40 48,24 69,15'], H: [93, '17,3 17,51 11,94;17,51 68,47 73,44 80,45 85,49;74,105 72,99 70,61 70,47 72,44 66,14;70,47 72,45'],
  I: [75, '10,91 16,94 34,91 65,83;64,14 53,13 23,16 12,23;32,16 37,48 38,90'], J: [83, '6,89 14,93 28,95 40,95 47,90 49,81 47,11;72,7 49,9 47,11 36,11 26,13 20,12'],
  K: [100, '15,96 17,88 16,65 19,54 17,53 14,19 11,5;19,54 36,50;71,15 42,38 38,43 36,50;36,50 43,59 57,69 71,79 96,92'], L: [88, '81,92 34,100 29,100 23,96 20,90 18,79 16,14 15,8 8,-3'],
  M: [125, '12,86 18,44 18,10 21,9 28,13 39,31 50,53 55,56 59,53 65,33 72,19 78,13 82,11 88,13 91,16 98,29 115,98'], N: [95, '78,8 80,26 80,85 78,86 71,83 37,37 29,29 24,27 20,30 19,37 13,90 14,94'],
  O: [96, '41,95 46,95 55,91 69,79 78,65 81,52 80,36 73,20 63,10 50,7 43,7 38,9 27,20 20,32 16,51 16,71 19,83 27,91 41,95'], P: [85, '40,51 54,42 68,25 76,11 76,0 72,-3 64,-4 47,-2 32,5 19,16 20,33 15,105'],
  Q: [105, '19,21 24,15 19,21 28,18 41,6 49,2 62,3 76,11 86,24 88,39 83,54 74,70 62,80 53,82 41,81 31,75 23,65 17,47 15,27 19,21;24,15 24,15;94,91 88,89 32,95'],
  R: [83, '73,93 65,94 50,90 40,85 35,80 35,70 53,39 57,24 56,16 54,11 49,7 40,6 20,13 16,17 14,22 16,94'],
  S: [79, '10,88 14,94 25,96 47,93 59,90 63,86 63,78 59,73 26,57 16,48 13,43 12,33 18,23 27,19 40,16 53,16 61,18 65,22 65,27'], T: [83, '76,-1 36,5 14,6 7,5;39,-9 41,3 43,4 46,102;41,3 43,4'],
  U: [93, '63,2 69,9 75,21 77,37 77,54 74,64 68,76 57,88 49,93 41,95 33,94 24,89 19,83 15,72 13,59 12,33 15,25'], V: [92, '8,31 38,89 42,91 47,89 55,75 86,-16'],
  W: [129, '3,24 12,36 37,87 42,89 46,87 62,40 66,38 71,39 74,42 87,65 101,82 109,86 112,83 114,73 120,9'], X: [90, '6,20 71,83 79,90 83,91;80,14 35,55 13,86 10,88'],
  Y: [92, '7,13 11,15 54,48;29,107 33,95 52,56 53,49 57,47 80,-1 84,-5'], Z: [107, '12,14 75,15 77,17 77,23 75,28 36,81 33,92 101,83'],
  a: [73, '11,44 32,44 39,45 41,47 39,54 14,82 12,89 13,97 17,100 25,100 35,93 43,84 48,82;63,99 56,93 51,84 48,82;48,82 49,63'],
  b: [70, '12,-5 19,61 23,64 22,87;35,104 41,103 48,97 56,83 59,66 57,48 52,40 43,40 36,47 29,59 23,64'], c: [58, '46,49 42,44 36,42 31,43 23,47 13,59 11,65 11,74 12,80 17,87 28,96 39,97 51,88'],
  d: [65, '48,67 42,71 33,89 25,93 19,93 15,88 12,79 11,67 14,52 21,44 32,39 43,39 49,41;54,95 52,88 51,71 48,67 51,5'],
  e: [70, '15,70 26,67 43,57 50,49 51,43 49,40 41,39 35,40 29,43 22,49 15,61 14,69 16,80 23,91 33,96 49,96 61,93'], f: [61, '53,50 24,53 7,57;47,7 42,0 34,-2 25,5 22,14 21,53 24,56 32,103 29,122;22,54 23,54'],
  g: [62, '41,68 36,72 24,86 16,87 12,83 11,74 13,62 19,52 27,44 34,42 40,44 43,50 41,68 43,70 44,74 49,109 47,136 41,146 36,147 32,145 20,131'], h: [71, '11,17 14,31 15,81 18,83 23,81 28,76 38,57 44,55 47,57 57,91 60,96 63,98'],
  i: [32, '16,56 15,72 17,98;16,32 24,41'], j: [48, '4,120 4,124 11,132 21,136 24,135 28,132 32,123 36,97 30,53 31,48;28,28 28,28'],
  k: [72, '11,94 15,80 16,57 21,11;15,82 24,83 27,88 35,92 62,96;25,83 28,80 41,73 51,62 55,54 56,42 46,44 34,54 24,66 16,69'], l: [35, '22,98 20,91 15,19 13,5 11,0'],
  m: [113, '11,42 13,83 15,92 18,93 22,91 41,55 46,53 50,54 57,83 61,85 67,82 79,55 85,52 89,55 102,93'], n: [72, '60,103 56,79 52,64 48,59 40,59 36,63 25,84 19,88 15,85 12,59'],
  o: [61, '28,47 18,55 11,72 12,80 16,88 20,92 26,94 36,92 43,85 47,78 49,66 48,59 43,53 34,48 28,47'], p: [57, '19,85 27,83 38,74 42,67 44,57 41,49 36,45 18,45 20,134'],
  q: [78, '49,133 53,118 55,100 54,89 50,80 47,77 42,76 22,76 15,75 10,71 8,65 10,60 14,56 35,48 50,50 61,58;69,95 55,99 53,102 43,103 16,111'], r: [60, '13,94 13,71 11,69 9,49;13,71 20,67 25,54 31,46 51,35'],
  s: [63, '57,46 51,40 40,37 32,38 25,43 23,47 25,57 34,68 47,79 50,89 46,94 34,99 20,102 6,101'], t: [84, '4,37 50,33 68,34;36,5 32,46 33,61 37,76 45,89 52,96 64,100 76,98;33,34 32,35'],
  u: [64, '51,73 45,76 39,83 31,90 26,91 20,90 15,84 12,75 11,59 12,51;51,56 51,73 54,75 57,97'], v: [66, '58,43 50,57 41,85 37,88 31,84 18,57 12,49'],
  w: [99, '11,47 18,59 26,90 30,94 35,92 37,90 43,71 46,67 53,71 64,90 69,92 73,91 82,72 90,53'], x: [81, '9,95 14,95 21,88 37,70 37,66 65,39;78,99 71,98 39,73 37,70 36,66 16,44;37,70 37,66'],
  y: [67, '9,35 23,53 32,62 39,65 49,65;35,142 48,77 49,65 55,46 55,38'], z: [70, '14,43 32,42 41,43 49,47 51,52 50,56 45,61 15,84 11,91 11,97 25,97 59,92 64,89'],
  '0': [80, '49,17 41,16 38,21 27,24 21,31 16,43 13,60 15,76 19,89 27,95 36,94 49,84 60,71 65,57 66,43 63,30 55,20 49,17'], '1': [64, '11,33 16,31 37,12 43,9 46,11 46,48 44,112'],
  '2': [70, '61,94 34,95 14,94 13,91 15,84 45,41 55,21 56,14 55,8 51,4 41,1 27,3 13,9'], '3': [64, '10,108 20,105 34,97 47,82 54,67 52,56 48,51 42,48 28,46 32,36 53,15 55,11 54,7 39,6 21,9 16,9'],
  '4': [83, '77,64 72,63 46,67 43,69 23,75 14,75 9,71 9,62 11,54 18,35 32,14 35,11 42,7 44,1 47,-3;42,8 43,9 43,68 48,110;44,68 43,69'],
  '5': [85, '74,0 38,8 30,12 26,16 22,45 41,38 48,39 52,41 57,52 57,73 52,87 41,99 25,105 18,105 11,102'],
  '6': [73, '42,12 38,14 29,25 18,45 14,64 15,76 18,82 22,83 25,88 35,91 41,91 51,86 59,77 60,72 58,65 53,63 46,62 38,67 22,83'], '7': [86, '21,115 20,109 22,101 72,16 73,9 69,7 14,6'],
  '8': [80, '32,35 29,42 22,53 15,67 14,81 16,89 22,95 29,97 40,97 52,93 61,84 65,73 64,58 59,46 45,34 31,35 20,27 19,22 21,15 32,7 39,4 50,5 57,11 58,16 56,23 46,31 45,34;32,35 45,34'],
  '9': [70, '11,103 18,101 36,80 52,47 55,35 51,19 41,9 27,8 21,12 16,18 11,31 14,48 21,57 33,60'], '.': [30, '14,94 15,94'], ',': [31, '21,90 13,105 7,120 7,126'], '!': [40, '17,106 17,106;18,81 21,47 18,-7'],
  ':': [38, '16,31 17,31;21,79 21,79'], '?': [66, '12,14 16,9 32,-1 44,0 52,7 53,14 52,25 34,61 32,66 33,73;32,95 32,95'], '-': [64, '53,69 10,67'], '+': [96, '14,61 32,54 48,52 52,49 86,48;49,95 50,60 48,26 46,19;49,51 49,51'],
  '=': [92, '18,67 77,69;77,48 72,46 59,46 20,47'], '/': [62, '15,113 48,6 49,1'],
  '%': [109, '13,107 55,48 99,-1;27,17 40,13 45,13 48,17 47,30 44,36 37,41 29,42 21,35 20,30 21,24 27,17;85,76 86,66 83,61 78,60 71,62 63,69 60,76 59,80 62,89 70,90 76,88 82,83 85,76'],
  '$': [84, '64,5 43,5 40,9 32,11 22,17 17,22 17,29 18,35 26,40 65,52 68,57 70,62 67,74 64,77 54,81 35,83 20,79 13,73;43,-8 34,68 35,99 37,112 40,114;34,82 35,83;36,43 37,43;40,9 42,5'],
  '(': [61, '44,11 37,13 20,32 14,45 14,62 17,75 27,89 40,101 55,108'], ')': [51, '20,0 30,13 38,26 40,36 41,52 38,63 29,83 16,102 5,111'],
  '&': [82, '57,75 32,62 22,52 13,39 12,31 13,25 21,14 35,5 42,5 46,8 47,11 32,55 26,62 18,81 17,87 19,93 23,97 33,98 38,97 49,88 55,78 59,72 65,53;29,59 29,58'], '>': [80, '6,91 15,90 60,64 63,60 58,53 33,35 21,30 11,29'],
  '#': [105, '3,26 38,19 43,15 72,9 89,12;20,56 26,56 69,44 74,40 93,38 103,39;41,-4 45,74;42,18 42,16;43,50 45,50;73,83 72,9 70,3 69,-22;72,43 72,41'], "'": [31, '14,34 15,2']
};
// END-HAND-TABLE

// How much of the page is ink, measured from the rendered PNG (8-bit RGB or RGBA). Bold doodles land between 8% and 18%.
function inkShare(file) {
  const b = fs.readFileSync(file), W = b.readUInt32BE(16), H = b.readUInt32BE(20), bpp = b[25] === 6 ? 4 : 3, idat = [];
  if (b[24] !== 8 || (b[25] !== 6 && b[25] !== 2) || b[28]) return NaN;       // only plain 8-bit RGB or RGBA
  for (let p = 8; p < b.length;) { const n = b.readUInt32BE(p); if (b.toString('ascii', p + 4, p + 8) === 'IDAT') idat.push(b.subarray(p + 8, p + 8 + n)); p += 12 + n; }
  const raw = zlib.inflateSync(Buffer.concat(idat)), row = W * bpp, px = Buffer.alloc(row * H); let ink = 0;
  for (let y = 0; y < H; y++) { const f = raw[y * (row + 1)]; for (let i = 0; i < row; i++) {
    const x = raw[y * (row + 1) + 1 + i], a = i >= bpp ? px[y * row + i - bpp] : 0, u = y ? px[(y - 1) * row + i] : 0, c = i >= bpp && y ? px[(y - 1) * row + i - bpp] : 0;
    const pa = a + u - c, pr = Math.abs(pa - a) <= Math.abs(pa - u) && Math.abs(pa - a) <= Math.abs(pa - c) ? a : Math.abs(pa - u) <= Math.abs(pa - c) ? u : c;
    px[y * row + i] = (x + [0, a, u, (a + u) >> 1, pr][f]) & 255; } }
  for (let i = 0; i < px.length; i += bpp) { const lo = Math.min(px[i], px[i + 1], px[i + 2]), hi = Math.max(px[i], px[i + 1], px[i + 2]); if ((bpp === 3 || px[i + 3] > 128) && (lo < 170 || hi - lo > 60)) ink++; }
  return 100 * ink / (W * H);
}

const NEAT = 0.25;                                    // letters are written neater than the drawing is drawn: a share of the looseness
function Doodle(W, H, seed = 7, loose = 0.6) {       // loose: 0 = tidy, 0.6 = the loose hand, 1 = a kid with a marker
  const u = W / 100, pen = { heavy: 1.3 * u, line: 1.0 * u, fine: 0.5 * u };
  let s = seed >>> 0;
  const rnd = () => { s = (s + 0x6D2B79F5) | 0; let t = Math.imul(s ^ (s >>> 15), 1 | s); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  const jit = (a) => (rnd() * 2 - 1) * a;
  const lat = new Map(), L = (i) => { if (!lat.has(i)) lat.set(i, rnd() * 2 - 1); return lat.get(i); };
  const nz = (x) => { const i = Math.floor(x), f = x - i, t = f * f * (3 - 2 * f); return L(i) + (L(i + 1) - L(i)) * t; };
  const out = [], warns = [], texts = [], colors = new Set(), box = [1e9, 1e9, -1e9, -1e9];
  let xf = (p) => p, cur = {};                                   // current rotation (rot) and pen override (with)

  // ---------- geometry
  const dense = (pts, closed) => {                               // a point every ~0.6u so the wobble has something to bend
    const o = [], n = pts.length, m = closed ? n : n - 1;
    for (let i = 0; i < m; i++) { const a = pts[i], b = pts[(i + 1) % n], k = Math.max(1, Math.ceil(Math.hypot(b[0] - a[0], b[1] - a[1]) / (0.6 * u))); for (let j = 0; j < k; j++) o.push([a[0] + (b[0] - a[0]) * j / k, a[1] + (b[1] - a[1]) * j / k]); }
    if (!closed) o.push(pts[n - 1]); return o;
  };
  const wobble = (pts, amp, closed) => {                         // a slow, lazy drift: a hand, not a tremor. A long line bends once or twice; it does not wiggle evenly.
    const ox = rnd() * 999, oy = rnd() * 999, n = pts.length, at = [0]; for (let i = 1; i <= n; i++) at.push(at[i - 1] + Math.hypot(pts[i % n][0] - pts[i - 1][0], pts[i % n][1] - pts[i - 1][1]));
    const tot = at[closed ? n : n - 1], wl = Math.max(10 * u, 0.45 * tot), k = amp * (1 + Math.min(1.2, tot / (80 * u)));
    const off = (t) => [k * (nz(ox + t) + 0.25 * nz(ox + 77 + t * 3.3)), k * (nz(oy + t) + 0.25 * nz(oy + 77 + t * 3.3))], o0 = off(0), oN = off(tot / wl);
    return pts.map((p, i) => { const o = off(at[i] / wl), f = closed ? at[i] / tot : 0; return [p[0] + o[0] - (oN[0] - o0[0]) * f, p[1] + o[1] - (oN[1] - o0[1]) * f]; });   // a closed shape comes back to where it began
  };
  const spline = (P, closed) => {                                // smooth curve through points
    const o = [], n = P.length, g = (i) => closed ? P[(i + n) % n] : P[Math.max(0, Math.min(n - 1, i))];
    for (let i = 0; i < (closed ? n : n - 1); i++) { const p0 = g(i - 1), p1 = g(i), p2 = g(i + 1), p3 = g(i + 2); for (let j = 0; j < 12; j++) { const t = j / 12, t2 = t * t, t3 = t2 * t; o.push([0.5 * (2 * p1[0] + (p2[0] - p0[0]) * t + (2 * p0[0] - 5 * p1[0] + 4 * p2[0] - p3[0]) * t2 + (3 * p1[0] - p0[0] - 3 * p2[0] + p3[0]) * t3), 0.5 * (2 * p1[1] + (p2[1] - p0[1]) * t + (2 * p0[1] - 5 * p1[1] + 4 * p2[1] - p3[1]) * t2 + (3 * p1[1] - p0[1] - 3 * p2[1] + p3[1]) * t3)]); } }
    if (!closed) o.push(P[n - 1]); return o;
  };
  const arcPts = (cx, cy, rx, ry, a0, a1) => { const n = Math.max(8, Math.ceil(Math.abs(a1 - a0) * Math.PI / 180 * Math.max(rx, ry) / (0.5 * u))), o = []; for (let i = 0; i <= n; i++) { const a = (a0 + (a1 - a0) * i / n) * Math.PI / 180; o.push([cx + rx * Math.cos(a), cy + ry * Math.sin(a)]); } return o; };

  const PF = require("perfect-freehand");
  const ink = (p, w) => {      // the clean pen: one even, confident line, split at corners so corners stay crisp; dots stay dots
    let L=0; for (let i=1;i<p.length;i++) L+=Math.hypot(p[i][0]-p[i-1][0],p[i][1]-p[i-1][1]);
    const circ=(q,k)=>"M"+(q[0]-k).toFixed(1)+" "+q[1].toFixed(1)+"a"+k.toFixed(1)+" "+k.toFixed(1)+" 0 1 1 "+(2*k).toFixed(1)+" 0a"+k.toFixed(1)+" "+k.toFixed(1)+" 0 1 1 "+(-2*k).toFixed(1)+" 0";
    if (L < w * 1.2) return circ(p[0], w / 2);
    const runs=[[p[0]]]; for (let i=1;i<p.length;i++){ runs[runs.length-1].push(p[i]); if(i<p.length-1){ let t=Math.abs(Math.atan2(p[i][1]-p[i-1][1],p[i][0]-p[i-1][0])-Math.atan2(p[i+1][1]-p[i][1],p[i+1][0]-p[i][0])); if(t>Math.PI)t=2*Math.PI-t; if(t>0.6) runs.push([p[i]]);} }
    let d="";
    for (const r of runs){ const o=PF.getStroke(r,{size:w,thinning:0.1,smoothing:0.6,streamline:0.3,simulatePressure:false,start:{cap:true},end:{cap:true},last:true});
      if(o.length>2) d+="M"+o.map(v=>v[0].toFixed(1)+" "+v[1].toFixed(1)).join("L")+"Z"; d+=circ(r[0],w/2)+circ(r[r.length-1],w/2); }
    return d; };

  // ---------- the one place ink meets paper
  function put(pts, st = {}, closed = false, isText = false) {
    const w = st.w ?? cur.w ?? pen.line, c = st.c ?? cur.c ?? INK, f = closed ? (st.f ?? PAPER) : 'none';
    const dn = dense(pts, closed); let len = 0; for (let i = 1; i < dn.length; i++) len += Math.hypot(dn[i][0] - dn[i - 1][0], dn[i][1] - dn[i - 1][1]);
    const p = wobble(dn, st.amp ?? Math.min((0.1 + 0.3 * loose) * u, 0.012 * len), closed).map(xf);
    for (const q of p) { box[0] = Math.min(box[0], q[0] - w / 2); box[1] = Math.min(box[1], q[1] - w / 2); box[2] = Math.max(box[2], q[0] + w / 2); box[3] = Math.max(box[3], q[1] + w / 2); }
    if (w && w < 0.26 * u && !isText) warns.push(`hairline: a ${(w / u).toFixed(2)}u stroke will vanish on a phone (keep 0.3u or more, 0.45u for anything that matters)`);
    for (const k of [c, f]) if (![INK, PAPER, FADE, 'none', '#fff', '#ffffff'].includes(String(k).toLowerCase()) && k !== INK && k !== PAPER && k !== FADE) colors.add(k);
    const D = (q) => 'M' + q.map((v) => v[0].toFixed(1) + ' ' + v[1].toFixed(1)).join('L'); let path = p;
    if (closed) { out.push({ t: isText, s: `<path d="${D(p)}Z" fill="${f}"/>` }); path = [...p, p[0]];
      if (loose && st.amp !== 0) {                               // a hand does not close a shape neatly: the line runs a little past its own start
        const k = Math.max(2, Math.round(p.length * (0.03 + 0.06 * loose))), far = Math.min(0.8 * loose * u, 0.025 * len), dx = jit(far), dy = jit(far);
        path = [...p, ...p.slice(0, k).map((q, i) => [q[0] + dx * (i + 1) / k, q[1] + dy * (i + 1) / k])]; } }
    if (!w) return;
    if (st.dash) out.push({ t: isText, s: `<path d="${D(path)}" fill="none" stroke="${c}" stroke-width="${w.toFixed(1)}" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="${st.dash}"/>` });
    else out.push({ t: isText, s: `<path d="${ink(path, w)}" fill="${c}" stroke="${c}" stroke-width="0" stroke-linejoin="round"/>` });
  }
  const d = { W, H, u, pen, loose, INK, HOT, GO, FADE, PAPER, rnd, jit };

  // ---------- strokes and shapes (closed shapes fill white by default, so things can sit in front of things)
  d.line = (x1, y1, x2, y2, st) => put([[x1, y1], [x2, y2]], st);
  d.poly = (pts, st) => put(pts, st);                            // open, sharp corners
  d.shape = (pts, st) => put(pts, st, true);                     // closed, sharp corners
  d.curve = (pts, st) => put(spline(pts, false), st);            // open, smooth
  d.blob = (pts, st) => put(spline(pts, true), st, true);        // closed, smooth
  d.oval = (cx, cy, rx, ry, st) => { const a0 = rnd() * 360; put(arcPts(cx, cy, rx, ry ?? rx, a0, a0 + 360).slice(0, -1), st, true); };
  d.arc = (cx, cy, rx, ry, a0, a1, st) => put(arcPts(cx, cy, rx, ry, a0, a1), st);
  d.dot = (x, y, r, c) => { const a = rnd() * Math.PI, k = r * (0.1 + 0.15 * rnd()); put([[x - k * Math.cos(a), y - k * Math.sin(a)], [x + k * Math.cos(a), y + k * Math.sin(a)]], { w: 2 * r, c: c ?? cur.c ?? INK, amp: 0 }); };   // a dab of the pen, never a perfect circle
  d.rect = (x, y, w, h, st = {}) => { const r = Math.min(st.r ?? 0, w / 2, h / 2); if (!r) return d.shape([[x, y], [x + w, y], [x + w, y + h], [x, y + h]], st); put([...arcPts(x + w - r, y + r, r, r, -90, 0), ...arcPts(x + w - r, y + h - r, r, r, 0, 90), ...arcPts(x + r, y + h - r, r, r, 90, 180), ...arcPts(x + r, y + r, r, r, 180, 270)], st, true); };
  d.tube = (pts, width, st = {}) => { const p = pts.length > 2 ? spline(pts, false) : pts, a = st.amp ?? 0.08 * u, s0 = s; put(p, { w: width + 2 * (st.w ?? cur.w ?? pen.line), c: st.c, amp: a }); s = s0; put(p, { w: width, c: st.f ?? PAPER, amp: a }); };  // an outlined limb, pipe or rail
  d.with = (st, fn) => { const p = cur; cur = { ...cur, ...st }; fn(); cur = p; };   // draw a group with another pen: d.with({ c: FADE }, () => ...)
  d.rot = (cx, cy, deg, fn) => { const a = deg * Math.PI / 180, co = Math.cos(a), si = Math.sin(a), prev = xf; xf = (p) => prev([cx + (p[0] - cx) * co - (p[1] - cy) * si, cy + (p[0] - cx) * si + (p[1] - cy) * co]); fn(); xf = prev; };

  // ---------- arrows: the verbs
  d.arrow = (x1, y1, x2, y2, st = {}) => {                       // st.bend bows the shaft (in u), st.head sizes the tip
    const b = (st.bend ?? 0) * u, mx = (x1 + x2) / 2, my = (y1 + y2) / 2, len = Math.hypot(x2 - x1, y2 - y1) || 1, nx = -(y2 - y1) / len, ny = (x2 - x1) / len, cx = mx + nx * b, cy = my + ny * b;
    d.curve([[x1, y1], [cx, cy], [x2, y2]], st);
    const a = Math.atan2(y2 - cy, x2 - cx), hl = st.head ?? 2.6 * u;
    d.poly([[x2 - hl * Math.cos(a - 0.55), y2 - hl * Math.sin(a - 0.55)], [x2, y2], [x2 - hl * Math.cos(a + 0.55), y2 - hl * Math.sin(a + 0.55)]], { ...st, amp: 0.05 * u });
  };
  d.bigArrow = (x1, y1, x2, y2, t, st = {}) => {                 // a fat arrow you can fill: "this becomes that"
    const len = Math.hypot(x2 - x1, y2 - y1), a = Math.atan2(y2 - y1, x2 - x1) * 180 / Math.PI, hl = Math.min(len * 0.45, t * 1.3);
    d.rot(x1, y1, a, () => d.shape([[x1, y1 - t / 2], [x1 + len - hl, y1 - t / 2], [x1 + len - hl, y1 - t], [x1 + len, y1], [x1 + len - hl, y1 + t], [x1 + len - hl, y1 + t / 2], [x1, y1 + t / 2]], { f: HOT, ...st }));
  };

  // ---------- lettering: written by the pen, never a font. Capitals or lowercase, as given; no two letters come out alike.
  d.textW = (str, size) => { let w = 0; for (const ch of String(str)) w += (ch === ' ' ? HAND.sp : G[ch] ? G[ch][0] : 50) * size / 100; return w; };
  d.text = (str, x, y, size, st = {}) => {                       // y is the line the letters sit on; size is the height of a capital. An array is stacked lines.
    if (Array.isArray(str)) { str.forEach((ln, i) => d.text(ln, x, y + i * size * (st.lead ?? 1.5), size, st)); return; }
    str = String(str); const low = str !== str.toUpperCase(); if (str.length > 1) texts.push({ str, size });      // a lone $ or ? is a symbol, not lettering
    if (str.length > 1 && size * (low ? HAND.xh / 100 : 1) < 2.6 * u) warns.push(`small letters: "${str}" is ${(size / u).toFixed(1)}u tall; it won't read on a phone (capitals 2.6u or more, lowercase ${(260 / HAND.xh).toFixed(1)}u or more)`);
    // one marker for everything: the pen does not get fatter because the letters got bigger
    const ll = st.loose ?? loose * NEAT, tw = d.textW(str, size), w = st.w ?? Math.min(pen.line * 1.1, Math.max(size * 0.13, 0.3 * u)), drift = jit(0.03 * ll), grow = jit(0.05 * ll), lean = st.slant ?? jit(0.05 * ll);
    let cx = st.anchor === 'start' ? x : st.anchor === 'end' ? x - tw : x - tw / 2; const x0 = cx;
    const draw = () => { for (const ch of str) {
      if (ch === ' ') { cx += (HAND.sp / 100 + jit(0.05 * ll)) * size; continue; }
      const g = G[ch]; if (!g) { warns.push(`no letter for "${ch}"`); cx += 0.5 * size; continue; }
      // every letter is written fresh: its own size, height on the line, tilt, and a slow bend of its shape, so no two are the same
      const t = (cx - x0) / Math.max(tw, 1), sc = size / 100 * (1 + grow * (t - 0.5) + jit(0.02 + 0.07 * ll)), dy = jit((0.01 + 0.045 * ll) * size) + (cx - x0) * drift, tilt = jit(1 + 3.5 * ll), gx = cx, ph = rnd() * 99, bend = 1.6 * ll;
      const P = (px, py) => { const bx = px + bend * nz(ph + px * 0.021 + py * 0.013), by = py + bend * nz(ph + 40 + px * 0.017 - py * 0.019); return [gx + (bx + (100 - by) * lean) * sc, y - (100 - by) * sc + dy]; };
      d.rot(cx + g[0] * sc / 2, y - size / 2, tilt, () => { if (g[1]) for (const stroke of g[1].split(';')) {
        const n = stroke.split(/[ ,]/).map(Number), pts = []; for (let i = 0; i < n.length; i += 2) pts.push(P(n[i], n[i + 1]));
        if (pts.length === 2 && Math.hypot(n[2] - n[0], n[3] - n[1]) < 3) { const a = rnd() * Math.PI, k = w * (0.15 + 0.2 * rnd()); put([[pts[0][0] - k * Math.cos(a), pts[0][1] - k * Math.sin(a)], [pts[0][0] + k * Math.cos(a), pts[0][1] + k * Math.sin(a)]], { w: w * 1.15, c: st.c, amp: 0 }, false, str.length > 1); continue; }   // a dot: a dab of the pen
        const shut = pts.length > 3 && n[0] === n[n.length - 2] && n[1] === n[n.length - 1];
        if (shut && ll) pts.push([pts[1][0] + jit(0.03 * size), pts[1][1] + jit(0.03 * size)]);                      // a hand runs a little past where the loop began
        put(pts.length > 2 ? spline(pts, false) : pts, { w, c: st.c, amp: 0 }, false, str.length > 1); } });
      cx += (g[0] / 100 + 0.015 + jit(0.03 * ll)) * size * (sc * 100 / size); } };
    st.rot ? d.rot(x, y - size / 2, st.rot, draw) : draw();
  };

  // ---------- emphasis: use exactly one per doodle
  d.underline = (x, y, w, st = {}) => d.curve([[x, y], [x + w * 0.5, y + jit(0.4 * u)], [x + w, y - 0.3 * u]], { w: pen.heavy, c: HOT, ...st });
  d.ring = (cx, cy, rx, ry, st = {}) => put(arcPts(cx, cy, rx, ry, -120, 275).map((p, i, a) => [p[0] + (i / a.length) * 0.9 * u, p[1] - (i / a.length) * 0.9 * u]), { w: pen.heavy, c: HOT, ...st });  // a circle drawn round the point, ends not meeting
  d.zing = (x, y, r, a0 = -150, n = 3, st = {}) => { for (let i = 0; i < n; i++) { const a = (a0 + i * 30) * Math.PI / 180; d.line(x + r * Math.cos(a), y + r * Math.sin(a), x + r * 1.7 * Math.cos(a), y + r * 1.7 * Math.sin(a), { w: pen.fine, amp: 0.03 * u, ...st }); } };
  d.cross = (x, y, r, st = {}) => { d.line(x - r, y - r, x + r, y + r, { w: pen.heavy, c: HOT, ...st }); d.line(x + r, y - r, x - r, y + r, { w: pen.heavy, c: HOT, ...st }); };
  d.check = (x, y, r, st = {}) => d.poly([[x - r, y], [x - r * 0.3, y + r * 0.7], [x + r, y - r * 0.9]], { w: pen.heavy, c: GO, ...st });
  d.hatch = (x, y, w, h, st = {}) => { const gap = st.gap ?? 1.6 * u; for (let k = gap; k < w + h; k += gap) d.line(x + Math.max(0, k - h), y + Math.min(h, k), x + Math.min(w, k), y + Math.max(0, k - w), { w: pen.fine, c: HOT, amp: 0.06 * u, ...st }); };
  d.bubble = (x, y, w, h, tail, st = {}) => {                    // speech bubble; tail is the point it speaks from
    const cx = x + w / 2, cy = y + h / 2, a = Math.atan2(tail[1] - cy, tail[0] - cx) * 180 / Math.PI;
    put([...arcPts(cx, cy, w / 2, h / 2, a + 14, a + 346), tail], st, true);
  };

  // ---------- the cast
  const POSE = { down: [[-0.19, -0.37], [0.19, -0.37]], up: [[-0.3, -0.97], [0.3, -0.97]], out: [[-0.38, -0.6], [0.38, -0.6]], point: [[-0.19, -0.37], [0.42, -0.66]], hold: [[0.2, -0.5], [0.36, -0.5]], shrug: [[-0.33, -0.56], [0.33, -0.56]], head: [[-0.18, -0.93], [0.18, -0.93]], hips: [[-0.15, -0.42], [0.15, -0.42]] };
  const figPen = (h) => Math.min(pen.line, Math.max(0.55 * u, 0.035 * h));        // figures share the picture's pen; only a small one gets a finer line
  const hands = (o) => { const A = Array.isArray(o.arms) ? o.arms : POSE[o.arms ?? 'down']; return (o.look ?? 0) < 0 && !Array.isArray(o.arms) ? [[-A[1][0], A[1][1]], [-A[0][0], A[0][1]]] : A; };
  function face(cx, cy, R, mood, look) {
    const ex = look * 0.24 * R, e = 0.34 * R, y0 = cy - 0.06 * R, st = { w: Math.max(0.13 * R, 0.3 * u), amp: 0.02 * u };
    d.dot(cx + ex - e, y0, 0.1 * R); d.dot(cx + ex + e, y0, 0.1 * R);
    const m = (pts) => d.curve(pts.map((p) => [cx + ex + p[0] * R, cy + p[1] * R]), st);
    if (mood === 'happy') m([[-0.36, 0.3], [0, 0.55], [0.36, 0.3]]);
    else if (mood === 'wow') d.oval(cx + ex, cy + 0.45 * R, 0.13 * R, 0.17 * R, { ...st, f: cur.c ?? INK });
    else if (mood === 'flat') m([[-0.28, 0.44], [0.28, 0.44]]);
    else m([[-0.32, 0.56], [0, 0.37], [0.32, 0.56]]);            // sad, worried, mad
    if (mood === 'worried' || mood === 'mad') { const k = mood === 'worried' ? -1 : 1; for (const sx of [-1, 1]) d.line(cx + ex + sx * 0.54 * R, y0 - (0.38 + k * 0.11) * R, cx + ex + sx * 0.18 * R, y0 - (0.38 - k * 0.11) * R, st); }
  }
  // A stick figure. x = centre, y = the ground under the feet, h = height. o.mood happy|sad|worried|mad|flat|wow. o.look -1|0|1.
  // o.arms = a POSE name, or [[lx,ly],[rx,ry]]: where each hand is, in units of h, measured from the feet.
  // o.lean = degrees the body tips. o.walk = 1 for a stride. o.sweat = drops. o.hair = 'tuft' or 'long'. o.c = draw the whole figure in one colour.
  d.person = (x, y, h, o = {}) => d.with({ w: o.w ?? figPen(h), ...(o.c ? { c: o.c } : {}) }, () => {
    const look = o.look ?? 0, R = 0.15 * h, hip = [x, y - 0.4 * h], wk = o.walk ?? 0, a = { amp: 0.25 * (0.1 + 0.3 * loose) * u }, el = o.arms === 'hips' ? 0.17 : o.arms === 'head' ? 0.22 : 0.03;
    for (const sx of [-1, 1]) { const fx = x + (sx * (0.1 + wk * 0.1) + jit(0.025 * loose)) * h; d.poly([hip, [fx, y], [fx + (look || sx) * 0.06 * h, y]], a); }
    d.rot(hip[0], hip[1], o.lean ?? 0, () => {
      const cy = y - h + R, sh = [x, cy + R + 0.06 * h];
      d.line(x, cy + R, hip[0], hip[1], a);
      hands(o).forEach((hd, i) => { const sx = i ? 1 : -1, wig = Array.isArray(o.arms) ? 0 : 0.03 * loose, hp = [x + (hd[0] + jit(wig)) * h, y + (hd[1] + jit(wig)) * h], up = hp[1] < sh[1] ? -1 : 1; d.curve([sh, [(sh[0] + hp[0]) / 2 + sx * el * h, (sh[1] + hp[1]) / 2 + up * 0.03 * h], hp], a); });
      d.oval(x, cy, R, R * 1.06);
      if (o.hair === 'tuft') for (const k of [-1, 0, 1]) d.line(x + k * 0.3 * R, cy - 0.95 * R, x + k * 0.6 * R, cy - 1.45 * R, a);
      if (o.hair === 'long') for (const sx of [-1, 1]) d.curve([[x + sx * 0.3 * R, cy - R], [x + sx * 1.2 * R, cy - 0.3 * R], [x + sx * 1.1 * R, cy + 0.9 * R]], a);
      face(x, cy, R, o.mood ?? 'happy', look);
      if (o.sweat) for (const k of [0, 1]) { const dx = x - (look || 1) * (1.4 + k * 0.45) * R, dy = cy - (0.5 - k * 0.6) * R; d.blob([[dx, dy - 0.2 * R], [dx + 0.11 * R, dy + 0.08 * R], [dx, dy + 0.17 * R], [dx - 0.11 * R, dy + 0.08 * R]], { w: 0.5 * (o.w ?? figPen(h)), amp: 0.02 * u }); }
    });
  });
  // the AI: a stick robot. A box head with an antenna, a box body, line limbs. Same mood, look and arms as a person.
  d.robot = (x, y, h, o = {}) => d.with({ w: o.w ?? figPen(h), ...(o.c ? { c: o.c } : {}) }, () => {
    const look = o.look ?? 0, hw = 0.19 * h, hy = y - 0.9 * h, by = y - 0.55 * h, a = { amp: 0.25 * (0.1 + 0.3 * loose) * u };
    for (const sx of [-1, 1]) d.poly([[x + sx * 0.07 * h, by + 0.28 * h], [x + sx * 0.09 * h, y], [x + sx * 0.09 * h + (look || sx) * 0.06 * h, y]], a);
    d.line(x, hy + 0.3 * h, x, by, a);
    d.rect(x - 0.13 * h, by, 0.26 * h, 0.28 * h, { f: o.body ?? PAPER });
    hands(o).forEach((hd, i) => { const sx = i ? 1 : -1, sh = [x + sx * 0.13 * h, by + 0.06 * h], hp = [x + hd[0] * h, y + hd[1] * h]; d.curve([sh, [(sh[0] + hp[0]) / 2 + sx * 0.03 * h, (sh[1] + hp[1]) / 2 + 0.03 * h], hp], a); });
    d.line(x, hy, x, hy - 0.07 * h, a); d.oval(x, hy - 0.1 * h, 0.03 * h, 0.03 * h, a);
    d.rect(x - hw, hy, 2 * hw, 0.3 * h);
    face(x, hy + 0.15 * h, 0.18 * h, o.mood ?? 'happy', look);
  });

  // ---------- props: things you can drop on your foot. Build others the same way, from the shapes above.
  d.doc = (x, y, w, h, o = {}) => { d.rect(x, y, w, h, { r: 0.04 * w, c: o.c, f: o.f }); const top = o.label ? y + 0.36 * h : y + 0.2 * h; if (o.label) d.text(o.label, x + w / 2, y + 0.25 * h, Math.min(0.17 * h, 0.8 * w * 0.17 * h / d.textW(o.label, 0.17 * h)), { c: o.c }); for (let k = 0; k < (o.lines ?? 3); k++) d.line(x + 0.16 * w, top + k * 0.17 * h, x + (k % 2 ? 0.66 : 0.84) * w, top + k * 0.17 * h, { w: pen.fine, c: o.c, amp: 0.04 * u }); };
  d.bag = (x, y, r, o = {}) => { d.blob([[x - 0.3 * r, y - 1.5 * r], [x - 0.95 * r, y - 0.55 * r], [x - 0.8 * r, y], [x + 0.8 * r, y], [x + 0.95 * r, y - 0.55 * r], [x + 0.3 * r, y - 1.5 * r]], { f: o.f, c: o.c }); d.blob([[x - 0.42 * r, y - 1.5 * r], [x - 0.5 * r, y - 1.95 * r], [x, y - 1.75 * r], [x + 0.5 * r, y - 1.95 * r], [x + 0.42 * r, y - 1.5 * r], [x, y - 1.58 * r]], { f: o.f, c: o.c }); d.text('$', x, y - 0.32 * r, 0.75 * r, { c: o.c }); };
  d.coin = (x, y, r, o = {}) => { d.oval(x, y, r, r, o); d.text('$', x, y + 0.5 * r, r, { c: o.c }); };
  d.phone = (x, y, w, o = {}) => { d.rect(x, y, w, 1.9 * w, { r: 0.18 * w, ...o }); d.rect(x + 0.14 * w, y + 0.22 * w, 0.72 * w, 1.2 * w, { r: 0.05 * w, w: pen.fine, c: o.c }); d.dot(x + w / 2, y + 1.66 * w, 0.07 * w, o.c); };
  d.bulb = (x, y, r, o = {}) => { d.rect(x - 0.4 * r, y + 0.7 * r, 0.8 * r, 0.75 * r, { r: 0.12 * r, ...o }); d.oval(x, y, r, r, o); for (let a = -160; a <= -20; a += 35) d.line(x + 1.4 * r * Math.cos(a * Math.PI / 180), y + 1.4 * r * Math.sin(a * Math.PI / 180), x + 1.9 * r * Math.cos(a * Math.PI / 180), y + 1.9 * r * Math.sin(a * Math.PI / 180), { w: pen.fine, c: o.c }); };
  d.clock = (x, y, r, o = {}) => { d.oval(x, y, r, r, o); d.poly([[x, y - 0.62 * r], [x, y], [x + 0.42 * r, y + 0.2 * r]], { c: o.c, amp: 0.03 * u }); };
  d.shop = (x, y, w, o = {}) => { const h = 0.7 * w; d.rect(x, y - h, w, h, o); d.rect(x + 0.62 * w, y - 0.5 * h, 0.2 * w, 0.5 * h, { c: o.c }); d.rect(x + 0.14 * w, y - 0.5 * h, 0.34 * w, 0.28 * h, { c: o.c, w: pen.fine }); d.shape([[x - 0.06 * w, y - h], [x + 1.06 * w, y - h], [x + 0.98 * w, y - 1.3 * h], [x + 0.02 * w, y - 1.3 * h]], { f: o.f ?? PAPER, c: o.c }); if (o.label) d.text(o.label, x + w / 2, y - 1.07 * h, 0.15 * h, { c: o.c }); };
  // bars on a baseline: vals are real numbers, o.hot = index of the bar that is the point, o.labels under, o.tops over
  d.bars = (x, y, w, h, vals, o = {}) => { const n = vals.length, bw = w / (n * 1.6), mx = Math.max(...vals); d.line(x - 2 * u, y, x + w + 2 * u, y, { w: pen.heavy });
    vals.forEach((v, i) => { const bx = x + (i + 0.3) * (w / n), bh = Math.max(0.8 * u, h * v / mx), hot = i === o.hot; d.rect(bx, y - bh, bw, bh, { f: hot ? HOT : PAPER, c: hot ? HOT : INK });
      if (o.tops) d.text(o.tops[i], bx + bw / 2, y - bh - 1.6 * u, o.size ?? 3.4 * u, { c: hot ? HOT : INK }); if (o.labels) d.text(o.labels[i], bx + bw / 2, y + 5.4 * u, o.lsize ?? 2.8 * u); }); };

  // ---------- out
  d.report = () => { const w = [...new Set(warns)], m = 2 * u;
    if (box[0] < m || box[1] < m || box[2] > W - m || box[3] > H - m) w.push(`off the edge: ink reaches [${box.map((v) => Math.round(v))}] on a ${W}x${H} canvas; keep a 2u margin`);
    if (colors.size > 2) w.push(`${colors.size} accent colours; one, or the red-to-green pair`);
    if (texts.length > 6) w.push(`${texts.length} pieces of lettering; over six and it is a slide, not a doodle`);
    const words = texts.reduce((n, t) => n + t.str.split(' ').length, 0); if (words > 16) w.push(`${words} words in the picture; the picture should be doing that work`);
    return w; };
  d.svg = (words = true) => `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${H}" width="${W}" height="${H}"><rect width="100%" height="100%" fill="${PAPER}"/>${out.filter((e) => words || !e.t).map((e) => e.s).join('')}</svg>`;
  // writes name.svg, name.png (2x), name-bare.png (no words, for the blind read) and name-thumb.png (320 wide, for the squint)
  d.save = (name) => { fs.writeFileSync(name + '.svg', d.svg());
    const png = (svg, file, width) => { const tmp = file + '.svg'; fs.writeFileSync(tmp, svg);
      try { cp.execFileSync('rsvg-convert', ['-w', String(width), '-o', file, tmp], { stdio: 'ignore' }); }
      catch (e) { const { Resvg } = require('@resvg/resvg-js'); fs.writeFileSync(file, new Resvg(svg, { fitTo: { mode: 'width', value: width } }).render().asPng()); }
      finally { fs.unlinkSync(tmp); } };
    const r = d.report(); let ink = NaN;
    try { png(d.svg(), name + '.png', W * 2); png(d.svg(false), name + '-bare.png', W); png(d.svg(), name + '-thumb.png', 320); ink = inkShare(name + '-thumb.png'); }
    catch (e) { r.push('no PNG: only the SVG was written. Install a renderer (npm i @resvg/resvg-js) and save again'); }
    if (ink < 7) r.push(`thin: only ${ink.toFixed(1)}% of the page is ink. Make the hero bigger or fill a shape. Do not add more things`);
    if (ink > 20) r.push(`heavy: ${ink.toFixed(1)}% of the page is ink. Take something out`);
    console.log(`${name}  ink ${ink.toFixed(1)}%` + (r.length ? '' : '  ok')); for (const x of r) console.log('  ! ' + x); return r; };
  return d;
}
module.exports = { Doodle, SIZES, inkShare, INK, HOT, GO, FADE, PAPER };
```
